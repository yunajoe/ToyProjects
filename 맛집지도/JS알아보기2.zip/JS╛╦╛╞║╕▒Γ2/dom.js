const divTag = document.querySelector("div"); 
console.log(divTag); 
divTag.style.color = "blue";

const h1Tag = document.querySelector("h1");
console.log(h1Tag);
h1Tag.style.color = "red";
h1Tag.style.fontsize ="30px";

const h2Tag = document.querySelector("h2");
h2Tag.innerText = "안녕하세요22";
h2Tag.style.fontSize = "100px";  

/* 
console.log(container);  
console.log(container.parentElement);
console.log(container.children);
console.log(container.nextElementSibling);
*/ 


const standard = document.querySelector("div.container");
// container 클래스에 있는 모든 값들을 반환 
console.log("실습입니다아아");
// console.log(standard); 
//console.log(standard.children[0]); 
// console.log(standard.children[1]); 
console.log(standard.children[1].children[1]); 




/*  

document.querySelector(선택자)  --> 해당 선택자로 선택되는 요소를 선택함
document.querySelectorAll(선택자)  -->  해당 선택자로 선택되는 요소를 모두 선택함
document.getElementsByTagName(태그이름 ) --> 해당 태그 이름의 요소를 모두 선택함. (배열)
document.getElementsByClassName(클래스이름) --> 해당 아이디의 요소를 선택함
document.getElementById(아이디) --> 해당 클래스에 속한 요소를 모두 선택함(배열)
*/

console.log(document.querySelector("div.welcome"));
console.log(document.querySelectorAll("div"));
console.log(document.getElementsByTagName("div"));
console.log(document.getElementById("hi"));
console.log(document.getElementsByClassName("welcome"));

;