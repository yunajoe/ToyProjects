
// 방법1
const btn = document.getElementById("btn");
btn.addEventListener("click", function(event) {
    console.log(event); 
    document.getElementById("text").innerHTML = 
    "이 이벤트 타입은" + event.type + "입니다";
}) ;

// addEventListener(이벤트종류, 이벤트가 일어나면 수행할함수)

// 방법2
const btn2 = document.getElementById("btn2");
btn2.addEventListener("click", eventHandler);

function eventHandler(){
    console.log();
    document.getElementById("text2").innerHTML = "짜자아안";
}