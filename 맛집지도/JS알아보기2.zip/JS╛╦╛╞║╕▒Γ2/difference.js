var ele = document.createElement("h1");
ele.innerText = "element생성입니다"
document.body.appendChild(ele); 
var textnode1 = document.createTextNode("element 생성의 textnode1");
var textnode2 = document.createTextNode("body child의 textnode2");

ele.appendChild(textnode1);
document.body.appendChild(textnode2);


function getInnerText() {
    const element = document.getElementById("content");
    alert(element.innerText); // A, B 
}

function getInnerHTML() { 
    const element = document.getElementById("content");
    alert(element.innerHTML); //  <div>A</div>, <div>B</div>
}

