// div.inner 선택
let inner = document.querySelector(".inner");

// h1 태그 생성
let element = document.createElement("h1");
element.innerText = "element생성입니다"
// body에 붙이기
document.body.appendChild(element);

// h2태그, 노드생성
let textnode = document.createTextNode("텍스트노트입니다아");
document.body.appendChild(textnode);

// <div>hello</div>a 만들기 
element.appendChild(hello);

inner.appendChild(element);