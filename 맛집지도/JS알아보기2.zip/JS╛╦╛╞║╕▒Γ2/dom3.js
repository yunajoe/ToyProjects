// div#app 태그에  item을 넣는 예제 임미당

const data = [
    {title :"pizza", price:1000},
    {title :"hamburger", price:500},
    {title: "coffee", price:1000},
    {title:"donut",price:800},
];

let inner = document.querySelector("#app");
let str=""
for (let i in data) {
    let food = data[i]["title"];
    let price = data[i]["price"];
    str += `음식: ${food}, 가격: ${price} <br>`
}

inner.innerHTML = str;
