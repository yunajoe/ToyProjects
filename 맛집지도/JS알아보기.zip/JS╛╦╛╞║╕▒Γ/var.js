/*   var은
    함수 레벨 스코프(Function-level scope)
    함수 내에서 선언된 변수는 함수 내에서만 유효하며 함수 외부에서는 참조할 수 없다. 즉, 함수 내부에서 선언한 변수는 지역 변수이며 함수 외부에서 선언한 변수는 모두 전역 변수이다.
    즉, 코드 블록 내부에서 선언된 변수도 전역변수다

*/

var foo = 123;
console.log(foo); // 전역변수 , 123

{
    var foo =456; 
    // var은 block level scope을 따르지 않기 때문에 블럭 안의 var도 전역변수이다.
}
console.log(foo); // 전역변수 , 456


// 변수 재선언 가능하다
var hello = "안녕하세요";
var hello = "헬로우";