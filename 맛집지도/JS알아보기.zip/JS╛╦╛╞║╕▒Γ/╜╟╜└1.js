const height = 170;
const weight = (height - 100) * 0.9

const sentence = "키는" + height + "cm이며 적정체중은" + weight + "kg입니다."

console.log(sentence);

console.log(`당신의 키는 ${height}cm이며 적정 체중은 ${weight}입니다.`)