/*   let은
    블럭 레벨 스코프(Function-level scope)
    함수 내에서 선언된 변수는 함수 내에서만 유효하며 함수 외부에서는 참조할 수 없다. 즉, 함수 내부에서 선언한 변수는 지역 변수이며 함수 외부에서 선언한 변수는 모두 전역 변수이다.
*/

let foo = 123;  // 전역변수

{
    let foo = 456; // 지역 변수, 즉 위에 foo=123이라고 한 것과는 별개의 변수당
    let bar = 100; // 지역 변수
    console.log(foo); // 지역변수 foo, 456
    console.log(bar);  // 지역변수 bar, 456

}

console.log(foo); // 전역변수, 123 
console.log(bar);  // 오류가 난다. 전역변수, 즉, 블럭 외부에서 선언을 안해줘서 인식X


// let은 변수가 재선언이 불가능하다 
let hello = "안녕하세요";
let hello = "헬로우";