const NameList = ["짱구","철수"];

// 훈이 배열 끝에 추가하기!
console.log('훈이를 배열 끝에 추가했어욤'); 
NameList.push("훈이");
console.log(NameList);

// 철수를 유리로 바꾸기 
console.log('철수를 유리로 바껐습니당'); 
NameList.splice(1,1,"유리");
console.log(NameList);

// 짱구 삭제 

NameList.splice(0,1);
console.log('짱구삭제');  
console.log(NameList);