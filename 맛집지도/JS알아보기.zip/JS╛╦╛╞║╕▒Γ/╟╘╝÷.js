let total=0;
for (let i=1; i<=10; i++){
    total = total + i // total은 전역으로 선언이됬는데.. 함수내에서 어케쓰이지?흠
}
console.log(total);

console.log(cal(50));
function cal(num) {
    let result=0;
    for (let i=1; i<=num; i++){
        result = result + i;
    }
    return result;
}

