// 배열 create
const arr = [1,2,3,4];

// 배열 read 
console.log(arr[0]);
console.log(arr[3]);

// 배열 길이 
console.log(arr.slice(1,3)); // index 1,2를 가지고 옴.따라서 2

// 배열 update 
arr[0] = 100; 
console.log(arr);

// 배열 delete
arr.splice(0,3);  // index 0~2 삭제
console.log(arr)

// 객체 

// 객체 create 
let userInfo = {
    email: "yunajoe@gmail.com",
    password: "1234",
}

// 객체 read 
console.log(userInfo.email);
console.log(userInfo["email"]);

// 객체 update 
userInfo.email = "updated된 이메일";
console.log(userInfo.email);

// 객체 delete 
delete userInfo.email;
console.log(userInfo);