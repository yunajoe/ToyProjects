// let으로 하깅  
let i = 10; 

while (i <=50) {      // i<50 이라고, 이미 전역변수로 할당이됨 그래서 코드블럭 안에서도 쓸 수 있는고임
    
    if (i % 5 === 0){
        console.log(i);
    }
    i++;
}

for (let i = 1; i<=10; i++){
    console.log("안뇽");
}

for (let i=1; i<=50; i++){
    if(i % 5 ===0){
        console.log(i);  
    }
    i = i + 1;
}


// var로 하깅
var s = 1; 

while (s <=50) {      // i<50 이라고, 이미 전역변수로 할당이됨 그래서 코드블럭 안에서도 쓸 수 있는고임
    
    if (s % 5 === 0){
        console.log(s);
    }
    s++;
}

// 배열 반복문
const arr = [1,2,3,4];

// 인덱스사용
for (let idx in arr){
    console.log(arr[idx]);
}

// 아이템 직접 접근
for (let item of arr){
    console.log(item);
}

const jsonArr = {email:"yunajoe@gmail.com", password:"1234"};

for (let k in jsonArr){
    console.log(jsonArr[k]);
}


// break, 숫자가 5이상이면은 break


for(let num=1; num<=10; num++){  
  if(num >=5){
     break
  }else{
    console.log(num);
  }
}

//continue를 반나면 그냥 건너뜀

for (let num =1; num<=10; num++){
    if(num==5){
        continue;
    }
    console.log(num);
}
