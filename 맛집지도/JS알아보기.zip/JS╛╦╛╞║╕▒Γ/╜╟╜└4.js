function BMI(height, weight){
    let meterheight = height/100;
    let bmi = weight / (meterheight * meterheight);
    return bmi;

}
console.log(BMI(170,70));


