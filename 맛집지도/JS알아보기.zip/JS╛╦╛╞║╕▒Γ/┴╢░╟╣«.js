/* 
if (조건문){ 
    소스코드  
}
*/

const a = 1; 
if (a< 10) {
    console.log("a는 10보다 작다");
} else{
    console.log("a는 10보다 크거나 같다");
}


const a2 = 100;
if (a2 <10){
    console.log("a2는 100보다 작다");
} else if ( a2 ==10){
    console.log("a2는 10이다");
} else {
    console.log("a2는 100보다 크다")
}




const b = 0; // 0은 false
if (b){ // b가 참이면 실행
    console.log("b가 참이네유");
}

const c = 0;
if (!c){  // c가 거짓이면 실행
    console.log("c가 거짓이네유");
} 
