// 비교연산자
1. >  크다(작다)
2. >= 크거나 같다(작거나 같다)
3. === 같다 
4. !== 다르다 
5. == 같다 
6. != 다르다 


// 논리연산자 
1. ||
// or 연산자. 피연산자 중 값이 하나라도 true라면 true를 반환

2. && 
// and 연산자. 피연산자가 모두 true여야 true를 반환

3. ! 
// not 연산자. 논리의 반대값을 반환 


let option1 = 10 > 1;  // True 

let option2 = 2 == 3;  // False 

console.log(option1||option2); // True 
console.log(option && option2); // false 

console.log(!option1);
