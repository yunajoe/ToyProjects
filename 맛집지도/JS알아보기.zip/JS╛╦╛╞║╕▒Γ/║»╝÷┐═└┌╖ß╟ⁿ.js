
// 변수 
var num = 1;
var num = 10;
console.log("변수 var은 재선언이 가능하다")
console.log(num);

let num2 = 2; 
num2 = 20; 
console.log("변수 let은 재선언은 불가능, 재할당은 가능")
console.log(num2);


const num3 = 3; 
num3 = 30; 
console.log("변수 const은 재선언은 불가능, 재할당도 불가능")


//  데이터 타입 
// 1. 문자형 

let str = "js";
let str2 = 'js';

// 2. 숫자형 
let num = 1; 

// 3. 논리형 
let bool = true;
let t = 100 >10;

// 4. 배열


