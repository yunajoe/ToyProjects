import json 
import requests

#출처: 
# https://unfinishedgod.netlify.app/2021/04/28/python-%EC%B9%B4%EC%B9%B4%EC%98%A4-api%EB%A5%BC-%EC%82%AC%EC%9A%A9%ED%95%9C-%EC%A3%BC%EC%86%8C-%EC%9C%84%EA%B2%BD%EB%8F%84-%EC%B6%94%EC%B6%9C/
# https://developers.kakao.com/docs/latest/ko/local/dev-guide

# 주소를 받아서 위도/경도로 return 해 주는 함수 
# 이것을 js 에 녹일 수 있는 방법 찾기 
def addr_to_lat_long(address):   
    api_key = "8b23617349a83ae864658e5bd57e7626"
    url = f"https://dapi.kakao.com/v2/local/search/address.json?query={address}"
    headers = {"Authorization": "KakaoAK " + api_key}
    result = json.loads(str(requests.get(url, headers=headers).text))
    data = result["documents"][0]["address"]
    return float(data["x"]), float(data["y"])
print(addr_to_lat_long("서울 영등포구 대방천로 260"))